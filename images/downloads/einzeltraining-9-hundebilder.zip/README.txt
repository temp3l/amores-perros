Einzeltraining – 9 Hundebilder

Enthalten:
- 3 Cartoon-Varianten
- 3 photorealistische Varianten
- 3 alternative/stilisierte Varianten

Die Bilder wurden aus der erzeugten 3×3-Übersicht als einzelne Dateien
ohne die darunterliegenden Dateinamen-Beschriftungen exportiert.
