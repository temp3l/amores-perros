Startseite – 9 Hundebilder

Enthalten:
- 3 Cartoon-Varianten
- 3 photorealistische Varianten
- 3 alternative/stilisierte Varianten

Die Dateien wurden aus der zuvor erzeugten 3×3-Übersicht als einzelne Bilder exportiert.
